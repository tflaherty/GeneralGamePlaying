﻿using System;

namespace Gecko
{
	public struct DOMHighResTimeStamp
	{
		public double value;
	}
}