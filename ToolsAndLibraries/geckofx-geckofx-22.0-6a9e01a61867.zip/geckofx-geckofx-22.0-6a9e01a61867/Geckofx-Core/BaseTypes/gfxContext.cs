namespace Gecko
{
	public class gfxContext
	{
		
	}
}