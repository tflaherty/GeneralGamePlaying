C#Prolog Version 3.1.0 -- December 2012

This release is mainly intented for fixing a number of bugs and shortcomings. 
It contains little new funcionality. New / modified predicates are: 

� console/1
� date_part/2
� json_format/2
� json_xml/2/3/4
� readeof/2
� regex_match/3/4
� regex_replace/4
� shell/0/1/2/3
� string_datetime/2/4/7

Please consult the help/1 predicate for more information on each of these.

C#Prolog has been developed with Visual Studio 2008.
 
At the moment of writing this text, over 7,000 copies of this interpreter have been 
downloaded. Actually I do not have a clue what the interpreter is used for, as I 
receive very little feedback. No doubt there will be many downloads where people 
have a quick look at it and then come to the conclusion they won�t be going to use it. 
But if you serves a useful purpose for you, I would appreciate to hear about that!

John Pool
Amersfoort
Netherlands
