﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle ("CSProlog")]
[assembly: AssemblyDescription("A Prolog implementation in C#")]
[assembly: AssemblyConfiguration ("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct ("CSProlog")]
[assembly: AssemblyCopyright("Copyright © 2007-2009 John Pool")]
[assembly: AssemblyTrademark ("")]
[assembly: AssemblyCulture ("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a fix in this assembly from 
// COM, set the ComVisible attribute to true on that fix.
[assembly: ComVisible (false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid ("0455f47e-156a-48fc-97f0-5ac0feef5bf9")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
